import { useState } from "react";
import { ExternalLink, Github, ArrowRight } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

type Tab = "software" | "data" | "branding" | "docs";

interface Project {
  id: string;
  title: string;
  subtitle: string;
  desc: string;
  tags: string[];
  image: string;
  links?: { label: string; url: string; type: "github" | "live" }[];
  featured?: boolean;
  color: string;
}

const tabs: { id: Tab; label: string; emoji: string }[] = [
  { id: "software", label: "Software Engineering", emoji: "💻" },
  { id: "data", label: "Data & Analytics", emoji: "📊" },
  { id: "branding", label: "Branding & Business", emoji: "🎨" },
  { id: "docs", label: "Docs & Management", emoji: "📋" },
];

const projects: Record<Tab, Project[]> = {
  software: [
    {
      id: "se1",
      title: "E-Commerce Platform",
      subtitle: "Full-Stack Web App",
      desc: "Platform e-commerce lengkap dengan fitur manajemen produk, keranjang belanja real-time, integrasi payment gateway, dan dashboard admin yang komprehensif.",
      tags: ["React", "Node.js", "MySQL", "Express", "JWT"],
      image: "https://images.unsplash.com/photo-1774901128302-e2bbd154da44?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3ZWIlMjBhcHBsaWNhdGlvbiUyMGNvZGUlMjBkZXZlbG9wbWVudHxlbnwxfHx8fDE3NzcwNDMwMjV8MA&ixlib=rb-4.1.0&q=80&w=1080",
      links: [
        { label: "GitHub", url: "#", type: "github" },
        { label: "Live Demo", url: "#", type: "live" },
      ],
      featured: true,
      color: "#1E3A8A",
    },
    {
      id: "se2",
      title: "Academic Information System",
      subtitle: "Web Application",
      desc: "Sistem informasi akademik untuk manajemen jadwal kuliah, nilai mahasiswa, dan absensi digital dengan notifikasi real-time.",
      tags: ["JavaScript", "PHP", "MySQL", "Bootstrap"],
      image: "https://images.unsplash.com/photo-1760507363325-b1633ed2cdb1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBtaW5pbWFsaXN0JTIwdGVjaCUyMHdvcmtzcGFjZSUyMGRhcmt8ZW58MXx8fHwxNzc3MDQzMDEzfDA&ixlib=rb-4.1.0&q=80&w=1080",
      links: [{ label: "GitHub", url: "#", type: "github" }],
      color: "#2547B0",
    },
    {
      id: "se3",
      title: "Task Management REST API",
      subtitle: "Backend Service",
      desc: "RESTful API untuk manajemen tugas tim dengan fitur authentication, role management, deadline tracking, dan team collaboration.",
      tags: ["Node.js", "Express", "MySQL", "JWT", "REST API"],
      image: "https://images.unsplash.com/photo-1759661966728-4a02e3c6ed91?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkYXRhJTIwYW5hbHl0aWNzJTIwZGFzaGJvYXJkJTIwdmlzdWFsaXphdGlvbnxlbnwxfHx8fDE3NzcwNDMwMjV8MA&ixlib=rb-4.1.0&q=80&w=1080",
      links: [{ label: "GitHub", url: "#", type: "github" }],
      color: "#1E3A8A",
    },
  ],
  data: [
    {
      id: "da1",
      title: "Sales BI Dashboard",
      subtitle: "Business Intelligence",
      desc: "Dashboard interaktif untuk analisis penjualan multi-cabang menggunakan Tableau. Menampilkan tren bulanan, segmentasi pelanggan, dan forecasting revenue.",
      tags: ["Tableau", "MySQL", "Excel", "Python"],
      image: "https://images.unsplash.com/photo-1759661966728-4a02e3c6ed91?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkYXRhJTIwYW5hbHl0aWNzJTIwZGFzaGJvYXJkJTIwdmlzdWFsaXphdGlvbnxlbnwxfHx8fDE3NzcwNDMwMjV8MA&ixlib=rb-4.1.0&q=80&w=1080",
      links: [{ label: "Live Demo", url: "#", type: "live" }],
      featured: true,
      color: "#F97316",
    },
    {
      id: "da2",
      title: "Customer Churn Analysis",
      subtitle: "Data Analytics",
      desc: "Analisis churn pelanggan menggunakan Python dan machine learning untuk mengidentifikasi pola dan faktor risiko kehilangan pelanggan.",
      tags: ["Python", "Pandas", "Scikit-learn", "Matplotlib"],
      image: "https://images.unsplash.com/photo-1760507363325-b1633ed2cdb1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBtaW5pbWFsaXN0JTIwdGVjaCUyMHdvcmtzcGFjZSUyMGRhcmt8ZW58MXx8fHwxNzc3MDQzMDEzfDA&ixlib=rb-4.1.0&q=80&w=1080",
      links: [{ label: "GitHub", url: "#", type: "github" }],
      color: "#ea6c0a",
    },
  ],
  branding: [
    {
      id: "br1",
      title: "StartupX Brand Identity",
      subtitle: "Visual Identity Design",
      desc: "Desain identitas merek lengkap untuk startup teknologi lokal meliputi logo, color palette, typography system, dan brand guidelines 40 halaman.",
      tags: ["Figma", "Illustrator", "Brand Strategy", "Typography"],
      image: "https://images.unsplash.com/photo-1760386129108-d17b9cdfc4fa?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxicmFuZCUyMGlkZW50aXR5JTIwZGVzaWduJTIwbG9nbyUyMGNyZWF0aXZlfGVufDF8fHx8MTc3NzA0MzAyNXww&ixlib=rb-4.1.0&q=80&w=1080",
      links: [{ label: "View Case Study", url: "#", type: "live" }],
      featured: true,
      color: "#8B5CF6",
    },
    {
      id: "br2",
      title: "UMKM Digital Branding",
      subtitle: "Brand Revamp",
      desc: "Revitalisasi brand untuk UMKM kuliner lokal yang ingin memasuki pasar digital. Mencakup redesign logo, packaging, dan strategi social media.",
      tags: ["Figma", "Canva Pro", "Brand Identity", "Social Media"],
      image: "https://images.unsplash.com/photo-1760507363325-b1633ed2cdb1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBtaW5pbWFsaXN0JTIwdGVjaCUyMHdvcmtzcGFjZSUyMGRhcmt8ZW58MXx8fHwxNzc3MDQzMDEzfDA&ixlib=rb-4.1.0&q=80&w=1080",
      color: "#7C3AED",
    },
  ],
  docs: [
    {
      id: "do1",
      title: "Program Kerja Organisasi 2024",
      subtitle: "Strategic Planning",
      desc: "Dokumen program kerja tahunan Himpunan Mahasiswa Sistem Informasi mencakup roadmap kegiatan, anggaran, dan key performance indicators setiap divisi.",
      tags: ["Strategic Planning", "Documentation", "Leadership", "Project Management"],
      image: "https://images.unsplash.com/photo-1653669487003-7d89b2020f3c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdHVkZW50JTIwb3JnYW5pemF0aW9uJTIwbGVhZGVyc2hpcCUyMHRlYW0lMjBtZWV0aW5nfGVufDF8fHx8MTc3NzA0MzAyOHww&ixlib=rb-4.1.0&q=80&w=1080",
      links: [{ label: "View Document", url: "#", type: "live" }],
      featured: true,
      color: "#059669",
    },
    {
      id: "do2",
      title: "Laporan Penelitian Skripsi",
      subtitle: "Academic Research",
      desc: "Penelitian tentang implementasi sistem BI untuk optimasi pengambilan keputusan di UKM dengan metodologi Design Science Research.",
      tags: ["Research", "Academic Writing", "BI", "Data Analysis"],
      image: "https://images.unsplash.com/photo-1760507363325-b1633ed2cdb1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBtaW5pbWFsaXN0JTIwdGVjaCUyMHdvcmtzcGFjZSUyMGRhcmt8ZW58MXx8fHwxNzc3MDQzMDEzfDA&ixlib=rb-4.1.0&q=80&w=1080",
      color: "#10B981",
    },
  ],
};

function ProjectCard({ project }: { project: Project }) {
  return (
    <div
      className="group relative rounded-2xl border border-white/8 bg-[#0D1124] overflow-hidden hover:border-white/15 transition-all duration-300 hover:-translate-y-1 hover:shadow-2xl"
      style={{ boxShadow: "0 0 0 0 transparent" }}
    >
      {/* Image */}
      <div className="relative h-44 overflow-hidden">
        <ImageWithFallback
          src={project.image}
          alt={project.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0D1124] via-[#0D1124]/40 to-transparent" />

        {/* Featured badge */}
        {project.featured && (
          <div
            className="absolute top-3 left-3 px-2.5 py-1 rounded-full text-xs text-white"
            style={{
              background: project.color,
              fontFamily: "'Inter', sans-serif",
              fontWeight: 600,
            }}
          >
            Featured
          </div>
        )}
      </div>

      {/* Content */}
      <div className="p-5">
        <p
          className="text-white/30 text-xs mb-1"
          style={{ fontFamily: "'Inter', sans-serif" }}
        >
          {project.subtitle}
        </p>
        <h3
          className="text-white mb-2"
          style={{
            fontFamily: "'Plus Jakarta Sans', sans-serif",
            fontWeight: 600,
            fontSize: "1rem",
          }}
        >
          {project.title}
        </h3>
        <p
          className="text-white/45 text-sm mb-4 line-clamp-2"
          style={{ fontFamily: "'Inter', sans-serif", lineHeight: 1.65 }}
        >
          {project.desc}
        </p>

        {/* Tags */}
        <div className="flex flex-wrap gap-1.5 mb-4">
          {project.tags.map((tag) => (
            <span
              key={tag}
              className="px-2 py-0.5 rounded-md bg-white/5 border border-white/8 text-white/40 text-xs"
              style={{ fontFamily: "'Inter', sans-serif" }}
            >
              {tag}
            </span>
          ))}
        </div>

        {/* Links */}
        {project.links && project.links.length > 0 && (
          <div className="flex gap-2">
            {project.links.map((link) => (
              <a
                key={link.label}
                href={link.url}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs transition-all cursor-pointer"
                style={{
                  fontFamily: "'Inter', sans-serif",
                  fontWeight: 500,
                  ...(link.type === "github"
                    ? {
                        borderColor: "rgba(255,255,255,0.12)",
                        color: "rgba(255,255,255,0.5)",
                      }
                    : {
                        borderColor: `${project.color}40`,
                        background: `${project.color}15`,
                        color: project.color,
                      }),
                }}
              >
                {link.type === "github" ? (
                  <Github size={12} />
                ) : (
                  <ExternalLink size={12} />
                )}
                {link.label}
              </a>
            ))}
          </div>
        )}
      </div>

      {/* Hover border glow */}
      <div
        className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"
        style={{
          boxShadow: `inset 0 0 0 1px ${project.color}30`,
        }}
      />
    </div>
  );
}

export function ProjectsSection() {
  const [activeTab, setActiveTab] = useState<Tab>("software");

  return (
    <section id="projects" className="py-24 bg-[#0A0F1E] relative overflow-hidden">
      <div className="absolute bottom-0 left-0 w-96 h-96 rounded-full bg-[#F97316]/5 blur-3xl" />

      <div className="max-w-6xl mx-auto px-6">
        {/* Section Header */}
        <div className="mb-10">
          <div className="flex items-center gap-3 mb-3">
            <span className="w-8 h-px bg-[#F97316]" />
            <span
              className="text-[#F97316] text-sm uppercase tracking-widest"
              style={{ fontFamily: "'Inter', sans-serif", fontWeight: 500 }}
            >
              Projects
            </span>
          </div>
          <div className="flex flex-wrap items-end gap-4">
            <h2
              className="text-white"
              style={{
                fontFamily: "'Plus Jakarta Sans', sans-serif",
                fontWeight: 700,
                fontSize: "clamp(1.8rem, 4vw, 2.8rem)",
                lineHeight: 1.2,
                letterSpacing: "-0.02em",
              }}
            >
              Project{" "}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#4B7FE8] to-[#F97316]">
                Showcase
              </span>
            </h2>
            <p
              className="text-white/40 mb-1"
              style={{ fontFamily: "'Inter', sans-serif", fontSize: "0.9rem" }}
            >
              {projects[activeTab].length} projects
            </p>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex flex-wrap gap-2 mb-8 p-1 rounded-xl bg-white/3 border border-white/5 w-fit">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm transition-all cursor-pointer ${
                activeTab === tab.id
                  ? "bg-[#1E3A8A] text-white shadow-lg shadow-[#1E3A8A]/30"
                  : "text-white/40 hover:text-white/60 hover:bg-white/5"
              }`}
              style={{ fontFamily: "'Inter', sans-serif", fontWeight: activeTab === tab.id ? 500 : 400 }}
            >
              <span>{tab.emoji}</span>
              <span className="hidden sm:inline">{tab.label}</span>
              <span className="sm:hidden">{tab.label.split(" ")[0]}</span>
            </button>
          ))}
        </div>

        {/* Project Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
          {projects[activeTab].map((project) => (
            <ProjectCard key={project.id} project={project} />
          ))}
        </div>

        {/* View All CTA */}
        <div className="flex justify-center mt-10">
          <button
            className="flex items-center gap-2 px-6 py-3 rounded-xl border border-white/10 text-white/50 hover:text-white hover:border-white/20 hover:bg-white/5 transition-all text-sm cursor-pointer group"
            style={{ fontFamily: "'Inter', sans-serif" }}
          >
            Lihat Semua Project
            <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
          </button>
        </div>
      </div>
    </section>
  );
}
